<form action="<?php echo e(route('autores.store')); ?>" method="post">

	<?php echo csrf_field(); ?>

	Nome: <input type="text" name="nome">
	<br>
		<?php if($errors->has('nome')): ?>
			Deverá indicar um nome correto(Tem letras)<br>
		<?php endif; ?>

	Nacionalidade: <input type="text" name="nacionalidade">
	<br>
		<?php if($errors->has('nacionalidade')): ?>
			Deverá indicar uma nacionalidade correta(letras)<br>
		<?php endif; ?>

	Data de nascimento: <input type="date" name="data_nascimento">
	<br>

		<?php if($errors->has('data_nascimento')): ?>
			Deverá indicar uma data correta<br>
		<?php endif; ?>

	
	Fotografia: <input type="text" name="fotografia">
	<br>

		<?php if($errors->has('fotografia')): ?>
			Deverá indicar uma imagem correta<br>
		<?php endif; ?>

	
	<input type="submit" name="enviar">
</form><?php /**PATH C:\Users\Professor\Downloads\psicreate-main\livraria\resources\views/autores/create.blade.php ENDPATH**/ ?>