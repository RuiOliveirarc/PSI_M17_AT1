

	<?php $__env->startSection('titulo-pagina'); ?>
		Editoras
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('titulo'); ?>
		Editar Editoras
	<?php $__env->stopSection(); ?>


	<?php $__env->startSection('conteudo'); ?>

<form action="<?php echo e(route('editoras.update', ['id'=>$editora->id_editora])); ?>" method="post">

	<?php echo csrf_field(); ?>
	<?php echo method_field('patch'); ?>

	Nome: <input type="text" name="nome" value="<?php echo e($editora->nome); ?>">
	<br>
		<?php if($errors->has('nome')): ?>
			Deverá indicar um nome correto(Tem letras)<br>
		<?php endif; ?>

	Morada: <input type="text" name="morada" value="<?php echo e($editora->morada); ?>">
	<br>
		<?php if($errors->has('morada')): ?>
			Deverá indicar uma morada correta(letras)<br>
		<?php endif; ?>

	Observações: <textarea name="observacoes"><?php echo e($editora->observacoes); ?></textarea>
	<br>

		<?php if($errors->has('observacoes')): ?>
			Deverá indicar observacoes correto<br>
		<?php endif; ?>
	
	<input type="submit" name="enviar">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\livraria\resources\views/editoras/edit.blade.php ENDPATH**/ ?>