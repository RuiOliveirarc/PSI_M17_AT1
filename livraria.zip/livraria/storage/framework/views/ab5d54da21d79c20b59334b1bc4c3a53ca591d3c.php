<form action="<?php echo e(route('editoras.store')); ?>" method="post">

	<?php echo csrf_field(); ?>

	Nome: <input type="text" name="nome">
	<br>
		<?php if($errors->has('nome')): ?>
			Deverá indicar um nome correto(Tem letras)<br>
		<?php endif; ?>

	Morada: <input type="text" name="morada">
	<br>
		<?php if($errors->has('morada')): ?>
			Deverá indicar uma morada correta(letras)<br>
		<?php endif; ?>

	Observações: <textarea name="observacoes"></textarea>
	<br>

		<?php if($errors->has('observacoes')): ?>
			Deverá indicar observacoes correto<br>
		<?php endif; ?>
	
	<input type="submit" name="enviar">
</form><?php /**PATH C:\Users\Professor\Downloads\psicreate-main\livraria\resources\views/editoras/create.blade.php ENDPATH**/ ?>