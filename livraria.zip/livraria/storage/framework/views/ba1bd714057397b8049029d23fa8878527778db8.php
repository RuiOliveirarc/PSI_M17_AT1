ID:<?php echo e($livro->id_livro); ?><br>
Título:<?php echo e($livro->titulo); ?><br>
Idioma:<?php echo e($livro->idioma); ?><br>

<h3>Editora deste livro</h3>
<?php if(count($livro->editoras)>0): ?>

	<?php $__currentLoopData = $livro->editoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($editora->nome); ?><br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
<div class="alert alert-danger" role="alert">
	Sem editora definido
</div>
<?php endif; ?><?php /**PATH C:\Users\Filipe\Desktop\psiat5-main\livraria\resources\views/livros/show.blade.php ENDPATH**/ ?>