

	<?php $__env->startSection('titulo-pagina'); ?>
		Generos
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('titulo'); ?>
		Criar Novo Genero
	<?php $__env->stopSection(); ?>


	<?php $__env->startSection('conteudo'); ?>

<form action="<?php echo e(route('generos.store')); ?>" method="post">

	<?php echo csrf_field(); ?>

	Designação: <input type="text" name="designacao">
	<br>
		<?php if($errors->has('designacao')): ?>
			Deverá indicar um designacao correto(Tem letras)<br>
		<?php endif; ?>

	Observações: <textarea name="observacoes"></textarea>
	<br>

		<?php if($errors->has('observacoes')): ?>
			Deverá indicar observacoes correto<br>
		<?php endif; ?>
	
	<input type="submit" name="enviar">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\livraria\resources\views/generos/create.blade.php ENDPATH**/ ?>