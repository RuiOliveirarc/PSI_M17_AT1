

	<?php $__env->startSection('titulo-pagina'); ?>
		Generos
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('titulo'); ?>
		Criar Novo genero
	<?php $__env->stopSection(); ?>


	<?php $__env->startSection('conteudo'); ?>

<form action="<?php echo e(route('autores.store')); ?>" method="post">

	<?php echo csrf_field(); ?>

	Nome: <input type="text" name="nome">
	<br>
		<?php if($errors->has('nome')): ?>
			Deverá indicar um nome correto(Tem letras)<br>
		<?php endif; ?>

	Nacionalidade: <input type="text" name="nacionalidade">
	<br>
		<?php if($errors->has('nacionalidade')): ?>
			Deverá indicar uma nacionalidade correta(letras)<br>
		<?php endif; ?>

	Data de nascimento: <input type="date" name="data_nascimento">
	<br>

		<?php if($errors->has('data_nascimento')): ?>
			Deverá indicar uma data correta<br>
		<?php endif; ?>

	
	Fotografia: <input type="text" name="fotografia">
	<br>

		<?php if($errors->has('fotografia')): ?>
			Deverá indicar uma imagem correta<br>
		<?php endif; ?>

	
	<input type="submit" name="enviar">
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\livraria\resources\views/autores/create.blade.php ENDPATH**/ ?>