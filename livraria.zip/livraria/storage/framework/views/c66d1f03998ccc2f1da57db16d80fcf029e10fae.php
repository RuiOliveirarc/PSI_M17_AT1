<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo $__env->yieldContent('titulo-pagina'); ?></title>
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	
	<div style="background-color: gray">
		<div class="container">
			<div class="row">

				<div style="text-align: left" class="col-md-2">
						<a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                           	<?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
				</div>

				<div class="col-md-6">
					<h1 style="text-align: center">
						<?php echo $__env->yieldContent('titulo'); ?>
					</h1>
				</div>

				<div class="col-md-4" style="text-align: right;">
					<a href="/">
						<h2>
							HOME
						</h2>
					</a>
				</div>
				
			</div>
		</div>
	</div>


	<?php echo $__env->yieldContent('conteudo'); ?>


	<?php if(session()->has('mensagem')): ?>
		<div class="alert alert-danger" role="alert">
			<?php echo e(session('mensagem')); ?>

		</div>
	<?php endif; ?>


	<script src="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
</body>
</html><?php /**PATH D:\livraria\resources\views/layouts/layout.blade.php ENDPATH**/ ?>