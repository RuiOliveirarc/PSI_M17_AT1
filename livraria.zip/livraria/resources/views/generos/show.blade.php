ID:{{$genero->id_genero}}<br>
Nome:{{$genero->designacao}}<br>
Observacao:{{$genero->observacoes}}<br>
