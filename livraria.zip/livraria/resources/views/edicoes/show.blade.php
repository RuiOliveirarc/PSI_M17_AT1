ID Livro: {{$edicao->id_livro}}<br>
ID Editora: {{$edicao->id_editora}}<br>
Data: {{$edicao->data}}<br>
Observacao: {{$edicao->observacoes}}